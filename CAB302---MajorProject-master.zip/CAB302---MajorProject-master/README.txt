Please enter the following command into powershell/cmd when in the current directory tto start the program:

java -classpath "Mazeco.jar;mariadb-java-client-3.0.5.jar" MainFunction
