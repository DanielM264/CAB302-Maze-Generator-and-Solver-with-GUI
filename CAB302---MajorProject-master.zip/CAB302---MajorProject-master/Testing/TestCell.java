import Maze.Cell;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestCell {
    Cell testCell;
    Cell testParentCell;

    @BeforeEach
    public void ConstructCell(){
        testCell = new Cell(1,1);
    }

    @Test
    public void testVisitedTrue() {
        testCell.setVisited(true);
        boolean visited = testCell.isVisited();
        assertEquals(true, visited);
    }

    @Test
    public void testVisitedFalse() {
        testCell.setVisited(false);
        boolean visited = testCell.isVisited();
        assertEquals(false, visited);
    }

    @Test
    public void testPathTrue() {
        testCell.setPath(true);
        boolean path = testCell.isPath();
        assertEquals(true, path);
    }

    @Test
    public void testPathFalse() {
        testCell.setPath(false);
        boolean path = testCell.isPath();
        assertEquals(false, path);
    }

    @Test
    public void testDeadEndTrue() {
        testCell.setDeadEnd(true);
        boolean deadEnd = testCell.isDeadEnd();
        assertEquals(true, deadEnd);
    }

    @Test
    public void testDeadEndFalse() {
        testCell.setDeadEnd(false);
        boolean deadEnd = testCell.isDeadEnd();
        assertEquals(false, deadEnd);
    }

    @Test
    public void testDistanceNormal() {
        testCell.setDistance(5);
        int distance = testCell.getDistance();
        assertEquals(5, distance);
    }

    @Test
    public void testDistanceUpper() {
        testCell.setDistance(99999999);
        int distance = testCell.getDistance();
        assertEquals(99999999,distance);
    }

    @Test
    public void testDistance0() {
        testCell.setDistance(0);
        int distance = testCell.getDistance();
        assertEquals(0, distance);
    }

    @Test
    public void testDistanceNegative() {
        testCell.setDistance(-5);
        int distance = testCell.getDistance();
        assertEquals(-5, distance);
    }

    @Test
    public void testParent() {
        testCell.setParent(testParentCell);
        Cell parentCell = testCell.getParent();
        assertEquals(testParentCell, parentCell);
    }

}