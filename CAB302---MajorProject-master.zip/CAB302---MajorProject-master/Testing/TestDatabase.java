

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Maze.*;
import GUI.*;
import Database.*;

public class TestDatabase {

    Database db;
    MazeGUI mgui = null;

    @BeforeEach
    public void ConstructDb()
    {
        assertDoesNotThrow(() -> {
            db = new Database();
            mgui.CreateMazeGUI(db, null);
        });

    }

    @AfterEach
    public void closeDb(){
        assertDoesNotThrow(() -> {
            db.closeDatabase();
        });
    }

    @Test
    public void TestSave()
    {
        Cell testC = new Cell(1,1);
        List<Cell> test = new ArrayList<>();
        test.add(testC);
        Maze savedMaze = new Maze("test", 2, 2,  test, test);
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        savedMaze.setCreationDate(df.format(new Date()));
        savedMaze.setAuthor("test");

        assertDoesNotThrow(() -> {
            db.saveMaze(savedMaze);
        });
    }
    @Test
    public void TestSaveTwice()
    {
        Cell testC = new Cell(1,1);
        List<Cell> test = new ArrayList<>();
        test.add(testC);
        Maze savedMaze = new Maze("test", 2, 2,  test, test);
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        savedMaze.setCreationDate(df.format(new Date()));
        savedMaze.setAuthor("test");


        assertDoesNotThrow(() -> {
            db.saveMaze(savedMaze);
        });

        assertThrows(SQLException.class,() -> {
            db.saveMaze(savedMaze);
        });
    }

    @Test
    public void TestUpdate(){
        Cell testC = new Cell(1,1);
        List<Cell> test = new ArrayList<>();
        test.add(testC);
        Maze updatedMaze = new Maze("test", 2, 2,  test, test);
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        updatedMaze.setCreationDate(df.format(new Date()));
        updatedMaze.setAuthor("test");

        assertDoesNotThrow(() -> {
            db.updateMaze(updatedMaze);
        });

        updatedMaze.mazeName = "notTest";

        assertThrows(Exception.class, () -> {
            db.updateMaze(updatedMaze);
        });
    }

    @Test
    public void TestLoad() {
        assertDoesNotThrow(() -> {
            db.loadMaze("test");
        });

        assertThrows(Exception.class, () -> {
            db.loadMaze("updatedMaze");
        });
    }

    @Test
    public void TestGetAllMazes(){
        assertDoesNotThrow(() -> {
            db.getAllMazes();
        });
    }

    @Test
    public void TestDelete(){
        Maze deletedMaze = new Maze();
        deletedMaze.mazeName = "test";
        assertDoesNotThrow(() -> {
            db.deleteMaze(deletedMaze);
        });
    }
}
