package Maze;


/**
 * Class that makes it easier to pass around the necessary data for the creation/ saving/updating of the maze
 */
public interface IMaze {

    /**
     * Sets the creation date of the maze
     *
     * @param creationDate creation date of the maze
     */
    void setCreationDate(String creationDate);

}
