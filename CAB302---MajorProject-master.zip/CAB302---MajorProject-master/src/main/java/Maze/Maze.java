package Maze;

import java.util.List;

/**
 * Class that makes it easier to pass around the necessary data for the creation/ saving/updating of the maze
 */
public class Maze implements IMaze{

    // Fields
    public String mazeName;
    public int cols;
    public int rows;
    public List<Cell> mazeCells;
    public List<Cell> solutionCells;
    public String authorName;
    public String creationDate;
    public String updateDate;

    // Constuctor
    public Maze(String mazeName,int cols, int rows, List<Cell> mazeCells, List<Cell> solutionCells){
        this.mazeName = mazeName;
        this.mazeCells = mazeCells;
        this.solutionCells = solutionCells;
    }

    // Blank constructor
    public Maze(){

    }
    public  void setCols(int col){this.cols = col;};
    public  void setRows(int row){this.rows = row;};
    public void setCreationDate(String date){
        this.creationDate = date;
    }
    public void setMaze(List<Cell> maze){
        this.mazeCells = maze;
    }
    public void setSolution(List<Cell> solution){
        this.solutionCells = solution;
    }
    public void setAuthor(String author){
        this.authorName = author;
    }
    public void setUpdateDate(String date){
        this.updateDate = date;
    }public void setMazeName(String mazeName){
        this.mazeName = mazeName;
    }

}
