package Maze;

import GUI.MazeGUI;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/*
Code from https://github.com/jaalsh/java-maze-algorithms

Authors: Jamie Sharpe, Garrie Mushet
 */

/**
 * This class serves as an object to store information on each individual 'cell' in the maze.
 * Code taken from: https://github.com/jaalsh/java-maze-algorithms
 * @author Jamie Sharpe & Garrie Mushet
 */

public class Cell implements Serializable {

    // Fields
    private int x, y, distance;

    private Cell parent;

    private boolean visited = false;
    private boolean path = false;
    private boolean deadEnd = false;

    private boolean[] walls = {true, true, true, true};

    /**
     * Constructor for the cell object
     * @param x X coordinate of the cell
     * @param y y coordinate of the cell
     */
    public Cell(int x, int y) {
        this.x = x;
        this.y = y;
        this.distance = -1;
    }

    /**
     * Returns whether the cell has been visited
     * @return Boolean value - whether the cell has been visited
     */
    public boolean isVisited() {
        return visited;
    }

    /**
     * Sets whether the cell has been visited
     * @param visited boolean; visited or not visited
     */
    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    /**
     * Returns whether the cell is a dead end
     * @return Boolean value representing whether the cell is a dead end
     */
    public boolean isDeadEnd() {
        return deadEnd;
    }


    /**
     * Sets the cell to be a dead end
     * @param deadEnd boolean; dead end or not
     */
    public void setDeadEnd(boolean deadEnd) {
        this.deadEnd = deadEnd;
    }

    /**
     * Returns whether the cell is part of the solution path
     * @return Boolean value whether the cell is part of the solution path
     */
    public boolean isPath() {
        return path;
    }


    /**
     * Sets the cell as part of the solution path
     * @param path boolean; part of the path or not
     */
    public void setPath(boolean path) {
        this.path = path;
    }

    /**
     * Return the distance
     * @return Integer for the distance of the cell
     */
    public int getDistance() {
        return distance;
    }

    /**
     * Sets the distance
     * @param distance
     */
    public void setDistance(int distance) {
        this.distance = distance;
    }

    /**
     * Returns the parent cell
     * @return The parent cell object
     */
    public Cell getParent() {
        return parent;
    }

    /**
     * Sets the parent cell
     * @param parent the parent cell
     */
    public void setParent(Cell parent) {
        this.parent = parent;
    }

    /**
     * Method to draw an image inside a cell
     *
     * Precondition - A maze has been created, full of cells, and an image file
     * Post condition - The selected image is displayed on the selected cell
     *
     * @param g Graphics object representing the cell
     * @param image Image file to draw
     */

    public void drawImage(Graphics g, Image image){
        int x2 = x * MazeGUI.W + 5;
        int y2 = y * MazeGUI.W + 5;
        g.drawImage(image, x2, y2, null);
    }

    /**
     * Method to draw the state of each cell, including the walls, background, and solution path
     *
     * Precondition - A maze grid has been declared
     * Post condition - The cell has been drawn
     *
     * @param g Graphics object representing the cell
     */
    public void draw(Graphics2D g) {
        int x2 = x * MazeGUI.W;
        int y2 = y * MazeGUI.W;
        g.setStroke(new BasicStroke(5));

        if (visited) {
            g.setColor(MazeGUI.backgroundColour);
            g.fillRect(x2, y2, MazeGUI.W, MazeGUI.W);
        }

        if (path) {
            g.setColor(MazeGUI.solutionColour);
            g.fillRect(x2, y2, MazeGUI.W, MazeGUI.W);
        } else if (deadEnd) {
            g.setColor(MazeGUI.solvingColour);
            g.fillRect(x2, y2, MazeGUI.W, MazeGUI.W);
        }

        g.setColor(MazeGUI.wallColour);
        if (walls[0]) {
            g.drawLine(x2, y2, x2+ MazeGUI.W, y2);
        }
        if (walls[1]) {
            g.drawLine(x2+ MazeGUI.W, y2, x2+ MazeGUI.W, y2+ MazeGUI.W);
        }
        if (walls[2]) {
            g.drawLine(x2+ MazeGUI.W, y2+ MazeGUI.W, x2, y2+ MazeGUI.W);
        }
        if (walls[3]) {
            g.drawLine(x2, y2+ MazeGUI.W, x2, y2);
        }
    }

    /**
     * Fills a cell with a given colour
     *
     * Precondition - A maze has been created, full of cells
     * Post condition - The selected cell has been filled with a chosen colour
     *
     * @param g The graphic object representing a cell
     * @param color The colour to paint with
     */
    public void displayAsColor(Graphics g, Color color) {
        int x2 = x * MazeGUI.W;
        int y2 = y * MazeGUI.W;
        g.setColor(color);
        g.fillRect(x2, y2, MazeGUI.W, MazeGUI.W);
    }

    /**
     * Removes the walls of a cell
     *
     * Precondition - A maze has been created, full of cells
     * Post condition - Walls have been removed from the cell
     *
     * @param next the next cell
     */
    public void removeWalls(Cell next) {
        int x = this.x - next.x;
        // top 0, right 1, bottom 2, left 3

        if(x == 1) {
            walls[3] = false;
            next.walls[1] = false;
        } else if (x == -1) {
            walls[1] = false;
            next.walls[3] = false;
        }

        int y = this.y - next.y;

        if(y == 1) {
            walls[0] = false;
            next.walls[2] = false;
        } else if (y == -1) {
            walls[2] = false;
            next.walls[0] = false;
        }
    }

    /**
     * Gets a random neighbouring cell
     * @param neighbours list of surrounding cells
     * @return A random neighbouring Cell object, or null
     */
    private Cell randomNeighbour(List<Cell> neighbours) {
        if (neighbours.size() > 0) {
            return neighbours.get(new Random().nextInt(neighbours.size()));
        } else {
            return null;
        }
    }

    /**
     * Check if the neighbouring cell is within the bounds of the grid
     * @param grid grid of cells making up the maze
     * @param neighbour neighbouring cell
     * @return Cell object of the neighbour if in the bounds, null otherwise
     */
    private Cell checkNeighbourInGridBounds(List<Cell> grid, Cell neighbour) {
        if (grid.contains(neighbour)) {
            return grid.get(grid.indexOf(neighbour));
        } else {
            return null;
        }
    }

    /**
     * Gets a neighbour that has not been visited previously
     * @param grid grid of cells making up the maze
     * @return Cell object of an unvisited neighbour
     */
    public Cell getUnvisitedNeighbour(List<Cell> grid) {

        List<Cell> neighbours = getUnvisitedNeighboursList(grid);

        if (neighbours.size() ==  1) {
            return neighbours.get(0);
        }
        return randomNeighbour(neighbours);
    }

    /**
     * Returns a list of unvisited neighbouring cells
     * @param grid grid of cells making up the maze
     * @return A list of Cell objects of all unvisited neighbours
     */
    public List<Cell> getUnvisitedNeighboursList(List<Cell> grid) {

        List<Cell> neighbours = new ArrayList<Cell>(4);

        Cell top = checkNeighbourInGridBounds(grid, new Cell(x, y - 1));
        Cell right = checkNeighbourInGridBounds(grid, new Cell(x + 1, y));
        Cell bottom = checkNeighbourInGridBounds(grid, new Cell(x, y + 1));
        Cell left = checkNeighbourInGridBounds(grid, new Cell(x - 1, y));

        if (top != null) if(!top.visited) neighbours.add(top);
        if (right != null) if(!right.visited) neighbours.add(right);
        if (bottom != null)if(!bottom.visited) neighbours.add(bottom);
        if (left != null) if(!left.visited)neighbours.add(left);

        return neighbours;
    }

    // no walls between

    /**
     * Returns a list of neighbouring cells that are able to be moved to - with no walls blocking the path
     * @param grid grid of cells making up the maze
     * @return A list of Cell objects of all neighbouring cells that are valid to move to
     */
    public List<Cell> getValidMoveNeighbours(List<Cell> grid) {
        List<Cell> neighbours = new ArrayList<Cell>(4);

        Cell top = checkNeighbourInGridBounds(grid, new Cell(x, y - 1));
        Cell right = checkNeighbourInGridBounds(grid, new Cell(x + 1, y));
        Cell bottom = checkNeighbourInGridBounds(grid, new Cell(x, y + 1));
        Cell left = checkNeighbourInGridBounds(grid, new Cell(x - 1, y));

        if (top != null) {
            if (!walls[0]) neighbours.add(top);
        }

        if (right != null) {
            if (!walls[1]) neighbours.add(right);
        }

        if (bottom != null) {
            if (!walls[2]) neighbours.add(bottom);
        }

        if (left != null) {
            if (!walls[3]) neighbours.add(left);
        }

        return neighbours;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + x;
        result = prime * result + y;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Cell other = (Cell) obj;
        if (x != other.x)
            return false;
        if (y != other.y)
            return false;
        return true;
    }
}
