package Maze;

import GUI.MazeGUI;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

/*
Code from: https://github.com/jaalsh/java-maze-algorithms

Authors: Jamie Sharpe, Garrie Mushet
 */

/**
 * Class for the drawing of the maze on a JPanel, and related methods
 * @author Jamie Sharpe & Gerrie Mushet
 */

public class MazeGridPanel extends JPanel {

    // Fields
    private static final long serialVersionUID = 7237062514425122227L;
    public List<Cell> grid = new ArrayList<Cell>();
    private List<Cell> currentCells = new ArrayList<Cell>();
    private Image startImage = ImageIO.read(MazeGUI.startFile);
    private Image endImage = ImageIO.read(MazeGUI.endFile);

    // Makes the generation algorithm a publicly accessible object
    public DFSGen generation;

    /**
     * The main panel for drawing the maze based on given dimensions
     * @param rows number of rows in the maze
     * @param cols number of columns in the maze
     */
    public MazeGridPanel(int rows, int cols, List<Cell> maze) throws IOException {
        if(maze == null){
            for (int x = 0; x < rows; x++) {
                for (int y = 0; y < cols; y++) {
                    grid.add(new Cell(x, y));
                }
            }
        } else{
            grid = maze;
        }
    }

    /**
     * Returns the given dimensions from the GUI module
     * @return Dimension object 
     */
    @Override
    public Dimension getPreferredSize() {
        // +1 pixel on width and height so bottom and right borders can be drawn.
        return new Dimension(MazeGUI.WIDTH + 1, MazeGUI.HEIGHT + 1);
    }

    /**
     * Starts the generation algorithm
     */
    public void generate() {
        generation = new DFSGen(grid, this);
    }

    /**
     * Starts the solution algorithm
     */
    public void solve() {
        new BFSSolve(grid, this);
    }

    /**
     * Resets the solution
     */
    public void resetSolution() {
        for (Cell c : grid) {
            c.setDeadEnd(false);
            c.setPath(false);
            c.setDistance(-1);
            c.setParent(null);
        }
        repaint();
    }

    /**
     * Calculates the difficulty of the maze - the percentage of cells needed to travel through for the solution.
     *
     * Precondition - A maze has been generated
     * Post condition - Returns the difficulty of the maze
     *
     * @return Integer representing the difficulty
     */
    public int calcDifficulty() {
        int pathCells = 0;
        for (Cell c : grid) {
            if (c.isPath()){
                pathCells++;
            }
        }
        float solutionPercentage = (float) pathCells / (float) grid.size();
        solutionPercentage = solutionPercentage * 100;
        return (int) solutionPercentage;
    }

    /**
     * Adds cells to the currentCells list, or sets the first cell in the list
     * @param current the current cell
     */
    public void setCurrent(Cell current) {
        if(currentCells.size() == 0) {
            currentCells.add(current);
        } else {
            currentCells.set(0, current);
        }
    }

    public void setCurrentCells(List<Cell> currentCells) {
        this.currentCells = currentCells;
    }

    /**
     * Paints each cell. Also paints the starting (top left) and ending (bottom right) cells different colours
     * @param g Graphics object representing the current cell
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Cell c : grid) {
            c.draw((Graphics2D) g);
        }
        for (Cell c : currentCells) {
            if(c != null) c.displayAsColor(g, Color.ORANGE);
        }

        Image startImage2;
        startImage2 = startImage.getScaledInstance(MazeGUI.W - 10,MazeGUI.W - 10,Image.SCALE_SMOOTH);
        Image endImage2;
        endImage2 = endImage.getScaledInstance(MazeGUI.W - 10,MazeGUI.W - 10,Image.SCALE_SMOOTH);

        if(MazeGUI.image){
            grid.get(0).drawImage(g, startImage2);
            grid.get(grid.size() - 1).drawImage(g, endImage2);
        } else {
            grid.get(0).displayAsColor(g, MazeGUI.startColour); // start cell
            grid.get(grid.size() - 1).displayAsColor(g, MazeGUI.endColour); // end or goal cell
        }

    }
}
