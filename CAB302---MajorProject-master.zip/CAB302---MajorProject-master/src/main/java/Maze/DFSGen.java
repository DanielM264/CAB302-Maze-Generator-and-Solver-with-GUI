package Maze;

import GUI.MazeGUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Stack;

import javax.swing.Timer;

/*
Code from https://github.com/jaalsh/java-maze-algorithms

Authors: Jamie Sharpe, Garrie Mushet
 */

/**
 * This class generates a maze given a particular size by 'carving' through a grid of cells
 * Code taken from: https://github.com/jaalsh/java-maze-algorithms
 * @author Jamie Sharpe & Garrie Mushet
 */

public class DFSGen {

    // Fields
    private final Stack<Cell> stack = new Stack<Cell>();
    public final List<Cell> grid;
    private Cell current;

    /**
     * Constructor of the generation algorithm
     * @param grid grid of cells that make up the maze
     * @param panel the panel for the maze to be drawn on
     */
    public DFSGen(List<Cell> grid, MazeGridPanel panel) {
        this.grid = grid;
        current = grid.get(0);

        // Generates the maze without an animation. Comment this out and uncomment the below block to include the animation.
        while(!MazeGUI.generated){
            if(!grid.parallelStream().allMatch(c -> c.isVisited())){
                carve();
            } else {
                current = null;
                MazeGUI.generated = true;
            }
            panel.setCurrent(current);
            panel.repaint();
        }

        // Generates the maze with an animation.
        //final Timer timer = new Timer(MazeGUI.speed, null);
        //timer.addActionListener(new ActionListener() {
        //    @Override
        //    public void actionPerformed(ActionEvent e) {
        //        if (!grid.parallelStream().allMatch(c -> c.isVisited())) {
        //            carve();
        //        } else {
        //            current = null;
        //            MazeGUI.generated = true;
        //            timer.stop();
        //        }
        //        panel.setCurrent(current);
        //        panel.repaint();
        //        timer.setDelay(MazeGUI.speed);
        //    }
        //});
        //timer.start();
    }

    /**
     * 'Carves' through the cells in the grid, removing walls and setting the current cell as 'visited'
     */
    private void carve() {
        current.setVisited(true);
        Cell next = current.getUnvisitedNeighbour(grid);
        if (next != null) {
            stack.push(current);
            current.removeWalls(next);
            current = next;
        } else if (!stack.isEmpty()) {
            try {
                current = stack.pop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}