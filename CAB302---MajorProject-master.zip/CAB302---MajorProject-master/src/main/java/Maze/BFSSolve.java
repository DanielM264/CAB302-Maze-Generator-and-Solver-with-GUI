package Maze;

import GUI.MazeGUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import javax.swing.Timer;

/*
Code from https://github.com/jaalsh/java-maze-algorithms

Authors: Jamie Sharpe, Garrie Mushet
 */

/**
 * This class traverses through a given maze and determines the best path.
 * Code taken from: https://github.com/jaalsh/java-maze-algorithms
 * @author Jamie Sharpe & Garrie Mushet
 */

public class BFSSolve {

    // Fields
    private final Queue<Cell> queue = new LinkedList<Cell>();
    private Cell current;
    public final List<Cell> grid;

    /**
     * Constructor of the solution algorithm. Takes two parameters, the 'grid' list object and the panel to draw on.
     *
     * Precondition - Both the GUI panel and maze grid have been created
     * Post condition - The maze has been solved, and the ideal path is painted
     *
     * @param grid list object that stores the cells of the maze
     * @param panel the JPanel that the maze and solution is drawn on
     */
    public BFSSolve(List<Cell> grid, MazeGridPanel panel) {
        this.grid = grid;
        current = grid.get(0);
        current.setDistance(0);
        queue.offer(current);


        // Generates the solution without an animation. Comment out this block and uncomment the below block to display the animation.
        while(!MazeGUI.solved){
            if (!current.equals(grid.get(grid.size() - 1))) {
                flood();
            } else {
                drawPath();
                MazeGUI.solved = true;
            }
            panel.setCurrent(current);
            panel.repaint();
        }

        // Generates the solution with an animation.
        //final Timer timer = new Timer(MazeGUI.speed, null);
        //timer.addActionListener(new ActionListener() {
        //    @Override
        //    public void actionPerformed(ActionEvent e) {
        //        if (!current.equals(grid.get(grid.size() - 1))) {
        //            flood();
        //        } else {
        //            drawPath();
        //            MazeGUI.solved = true;
        //            timer.stop();
        //        }
        //        panel.setCurrent(current);
        //        panel.repaint();
        //        timer.setDelay(MazeGUI.speed);
        //    }
        //});
        //timer.start();
    }

    /**
     * Moves through the maze and determines dead ends
     *
     * Precondition - A maze has been generated
     * Post condition - The ideal path has been found and painted
     *
     */
    private void flood() {
        current.setDeadEnd(true);
        current = queue.poll();
        List<Cell> adjacentCells = current.getValidMoveNeighbours(grid);
        for (Cell c : adjacentCells) {
            if (c.getDistance() == -1) {
                c.setDistance(current.getDistance() + 1);
                c.setParent(current);
                queue.offer(c);
            }
        }
    }

    /**
     * Determines whether each cell is part of the correct path
     *
     * Precondition - A maze has been generated and been 'flooded' by the solver
     * Post condition - The ideal path has been found and painted
     */
    private void drawPath() {
        while (current != grid.get(0)) {
            current.setPath(true);
            current = current.getParent();
        }
    }
}
