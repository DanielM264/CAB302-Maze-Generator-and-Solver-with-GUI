package GUI;

import Database.Database;
import Maze.MazeGridPanel;
import Maze.Maze;

import java.awt.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

import java.awt.Color;
import java.sql.SQLException;
import java.nio.file.Files;


public class MazeGUI extends JFrame {

    // Initialisations
    private JPanel mainPanel;
    private JPanel rightPanel;
    private JPanel leftPanel;
    private JPanel rightButtonPanel;
    private JPanel leftButtonPanel;
    private JPanel dbPanel;
    private JLabel lLabel = new JLabel("Columns:");
    private JLabel hLabel = new JLabel("Rows:");
    private SpinnerModel lSpinnerM;
    private JSpinner lSpinner;
    private SpinnerModel hSpinnerM;
    private JSpinner hSpinner;
    public JButton generateBtn = new JButton("Generate");
    public JButton newMazeBtn = new JButton("New maze");
    private JButton solutionBtn = new JButton("Show/hide solution");
    private JButton downloadAsPng = new JButton("Download as PNG");
    private JLabel percentageText = new JLabel("Percent of maze travelled for solution:");
    private JLabel percentageNum = new JLabel("Waiting for a maze...", SwingConstants.CENTER);
    private JCheckBox imageCheck = new JCheckBox("Create with images");
    private JButton startImageBtn = new JButton("Select start image");
    private JButton endImageBtn = new JButton("Select end image");
    private JLabel startImageLbl = new JLabel();
    private JLabel endImageLbl = new JLabel();
    private ImageIcon startImageIcon = new ImageIcon();
    private ImageIcon endImageIcon = new ImageIcon();

    public static int WIDTH;
    public static int HEIGHT;
    public static int W = 10;
    public static int PERCENTAGE;

    public static File startFile = new File("MazeImages/dog.png");
    public static File endFile = new File("MazeImages/bone.png");
    public static boolean generated, solved, started, image;
    public static Color backgroundColour = Color.white;
    public static Color wallColour = Color.black;
    public static Color startColour = Color.green;
    public static Color endColour = Color.yellow;
    public static Color solvingColour = Color.white;
    public static Color solutionColour = Color.blue;

    public int cols, rows;

    // Maze grid, publicly available for DB access
    public MazeGridPanel grid;

    private static Database inputDb;

    public MazeGUI(Database db, Maze loaded) throws IOException {
        super("Maze Generator");

        // Generate spinners
        if(loaded != null){
            lSpinnerM = new SpinnerNumberModel(loaded.rows, 5, 100, 1);
            hSpinnerM = new SpinnerNumberModel(loaded.cols, 5, 100, 1);
        } else {
            lSpinnerM = new SpinnerNumberModel(10, 5, 100, 1);
            hSpinnerM = new SpinnerNumberModel(10, 5, 100, 1);
        }
        lSpinner = new JSpinner(lSpinnerM);
        hSpinner = new JSpinner(hSpinnerM);
        // Pass database to class
        inputDb = db;

        cols = Math.floorDiv(WIDTH, W);
        rows = Math.floorDiv(HEIGHT, W);

        // Sets parameters for overall window
        setSize(900, 430);
        setLocation(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        JPanel bigPanel = new JPanel();
        bigPanel.setLayout(new BorderLayout());

        // Creates a tabbed window
        JTabbedPane pane = new JTabbedPane();

        // Creates the panel for the maze image
        mainPanel = new JPanel();
        mainPanel.setBackground(backgroundColour);

        // Creates the right hand panel with generation options
        rightPanel = new JPanel();
        rightPanel.setLayout(new FlowLayout(4, 4, 4));
        rightButtonPanel = new JPanel();
        rightButtonPanel.setLayout(new GridLayout(5, 1, 5, 30));
        rightButtonPanel.add(solutionBtn);
        rightButtonPanel.add(downloadAsPng);
        rightButtonPanel.add(percentageText);
        percentageNum.setFont(new Font("Arial", Font.BOLD, 20));
        rightButtonPanel.add(percentageNum);
        rightPanel.add(rightButtonPanel);

        // Creates the left hand panel with save options
        leftPanel = new JPanel();
        leftPanel.setLayout(new FlowLayout(4, 4, 4));
        leftButtonPanel = new JPanel();
        leftButtonPanel.setLayout(new GridLayout(6, 1, 5, 10));
        leftButtonPanel.add(generateBtn);
        leftButtonPanel.add(newMazeBtn);
        leftButtonPanel.add(lLabel);
        leftButtonPanel.add(hLabel);
        leftButtonPanel.add(lSpinner);
        leftButtonPanel.add(hSpinner);
        leftButtonPanel.add(startImageBtn);
        leftButtonPanel.add(endImageBtn);
        leftButtonPanel.add(startImageLbl);
        leftButtonPanel.add(endImageLbl);
        leftButtonPanel.add(imageCheck);
        leftPanel.add(leftButtonPanel);

        // Adds the maze sections to the maze tab
        bigPanel.add(mainPanel, BorderLayout.CENTER);
        bigPanel.add(rightPanel, BorderLayout.EAST);
        bigPanel.add(leftPanel, BorderLayout.WEST);

        // Creates the 'Maze' tab
        pane.add("Maze", bigPanel);

        // Creates the database tab
        dbPanel = new DatabaseGUI(pane, db, this);

        // Adds the tabbed pane to the window
        add(pane);

        // If loaded maze
        if(loaded != null){
            if(started){
                mainPanel.removeAll();
                mainPanel.revalidate();
                mainPanel.repaint();
            }

            rows = loaded.rows;
            cols = loaded.cols;

            if (rows > cols) {
                W = 800/rows;
            } else {
                W = 800/cols;
            }

            WIDTH = (rows * W);
            HEIGHT = (cols * W);

            int winWidth = WIDTH + 550;
            int winLength = HEIGHT + 130;

            super.setSize(winWidth, winLength);
            grid = new MazeGridPanel(rows, cols, loaded.mazeCells);
            grid.setBackground(backgroundColour);

            JPanel mazeBorder = new JPanel();
            final int BORDER_SIZE = 20;
            mazeBorder.setBounds(0, 0, WIDTH + BORDER_SIZE, HEIGHT + BORDER_SIZE);
            mazeBorder.setBackground(backgroundColour);
            mazeBorder.setBorder(BorderFactory.createEmptyBorder(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, BORDER_SIZE));
            mazeBorder.add(grid);
            mainPanel.add(mazeBorder);

        }

        // Sets up the file chooser
        FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG, JPG and GIF images", "jpg", "png", "gif");

        JFileChooser imageChooser = new JFileChooser(FileSystemView.getFileSystemView());
        imageChooser.setDialogTitle("Select an image");
        imageChooser.setAcceptAllFileFilterUsed(false);
        imageChooser.setFileFilter(filter);


        // Button events
        imageCheck.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                image = (e.getStateChange()==1?true:false);
            }
        });

        startImageBtn.addActionListener(event -> {
            int returnValue = imageChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION){
                startFile = imageChooser.getSelectedFile();
                startImageIcon = new ImageIcon(String.valueOf(startFile));
                Image img = startImageIcon.getImage();
                Image newimg = img.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
                System.out.println(startFile);
                startImageIcon = new ImageIcon(newimg);
                startImageLbl.setIcon(startImageIcon);
            }
        });

        endImageBtn.addActionListener(event -> {
            int returnValue = imageChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION){
                endFile = imageChooser.getSelectedFile();
                endImageIcon = new ImageIcon(String.valueOf(endFile));
                Image img = endImageIcon.getImage();
                Image newimg = img.getScaledInstance(30,30,Image.SCALE_SMOOTH);
                endImageIcon = new ImageIcon(newimg);
                endImageLbl.setIcon(endImageIcon);
            }
        });

        newMazeBtn.addActionListener(event -> {


            mainPanel.removeAll();
            mainPanel.revalidate();
            mainPanel.repaint();


            rows = (int) lSpinner.getValue();
            cols = (int) hSpinner.getValue();

            if (rows > cols) {
                W = 800/rows;
            } else {
                W = 800/cols;
            }

            WIDTH = (rows * W);
            HEIGHT = (cols * W);

            int winWidth = WIDTH + 550;
            int winLength = HEIGHT + 130;

            super.setSize(winWidth, winLength);

            /**
             * Following code taken from: https://github.com/jaalsh/java-maze-algorithms
             * Authors: Jamie Sharpe, Garrie Mushet
             */

            try {
                grid = new MazeGridPanel(rows, cols, null);
            } catch (IOException e) {
                e.printStackTrace();
            }
            grid.setBackground(backgroundColour);

            JPanel mazeBorder = new JPanel();
            final int BORDER_SIZE = 20;
            mazeBorder.setBounds(0, 0, WIDTH + BORDER_SIZE, HEIGHT + BORDER_SIZE);
            mazeBorder.setBackground(backgroundColour);
            mazeBorder.setBorder(BorderFactory.createEmptyBorder(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, BORDER_SIZE));
            mazeBorder.add(grid);
            mainPanel.add(mazeBorder);

            /**
             * End of modified code
             */

            percentageNum.setText("Waiting for a maze...");
            mainPanel.revalidate();
            started = true;

        });

        generateBtn.addActionListener(event -> {
            if(!started) {
                JOptionPane.showMessageDialog(this, "Please input a size and click 'New Maze' before you generate.");
            }
            else{
                generated = false;
                solved = false;
                grid.generate();
            }
        });

        solutionBtn.addActionListener(event -> {

            if(started){
                if(generated){
                    if(solved){
                        grid.resetSolution();
                        solved = false;
                    } else {
                        grid.solve();
                        PERCENTAGE = grid.calcDifficulty();
                        percentageNum.setText(PERCENTAGE + "%");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Please click 'generate' to create the maze first.");
                }
            } else if(loaded != null){
                if(!solved){
                    grid.solve();
                    PERCENTAGE = grid.calcDifficulty();
                    percentageNum.setText(PERCENTAGE + "%");
                } else{
                    grid.resetSolution();
                    solved = false;
                }
            }else {
                JOptionPane.showMessageDialog(this, "Please wait until the maze has been generated.");
            }
        });

        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {

                if(checkWork()){
                    JOptionPane.showConfirmDialog(null, "You will lose all unsaved work if you close.\n Are you sure you want to close?");
                    try{
                        db.closeDatabase();
                    } catch(SQLException error){
                        JOptionPane.showMessageDialog(null, "There was an error closing the database");
                    }
                    System.exit(0);
                }
            }
        });

        downloadAsPng.addActionListener(event -> {
            //open save dialogue
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new FileNameExtensionFilter("*.png", "png"));
            int returnVal = fileChooser.showSaveDialog(mainPanel);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                String path = fileChooser.getSelectedFile().toString();
                //Ensure save path ends with .png
                if (!path.endsWith(".png")) {
                    path = path + ".png";
                }
                //create an image of the mainPanel
                BufferedImage mazePNG = new BufferedImage(mainPanel.getSize().width, mainPanel.getSize().height, BufferedImage.TYPE_INT_ARGB);
                Graphics g = mazePNG.createGraphics();
                mainPanel.paint(g);  //this == JComponent
                g.dispose();
                //save the mainPanel image
                try {ImageIO.write(mazePNG, "png", new File(path));} catch (Exception e) {}
            }
        });
    }

    private boolean checkWork(){
        try{
            if(this.grid.grid != null){
                return true;
            } else{
                return false;
            }
        } catch(NullPointerException e){
            return false;
        }

    }

    public static void CreateMazeGUI(Database db,Maze loaded) throws IOException {
        JFrame.setDefaultLookAndFeelDecorated(true);
        MazeGUI gui = new MazeGUI(db, loaded);
        gui.setVisible(true);
    }


}