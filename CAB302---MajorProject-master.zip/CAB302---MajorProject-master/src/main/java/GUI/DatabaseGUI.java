package GUI;

import Maze.Maze;
import Database.Database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class DatabaseGUI extends JPanel {

    public static final String DATE_FORMAT_NOW = "yyyy-MM-dd";
    private JPanel northPanel;
    private JPanel southPanel;
    private JButton saveMazeBtn = new JButton("Save current maze");
    private JButton updateExistingMazeBtn = new JButton("Update existing maze");
    private JButton deleteMazeBtn = new JButton("Delete maze");
    private JButton loadMazeBtn = new JButton("Load Maze");
    private JLabel mazeNameLabel = new JLabel("Maze Name:");
    private JLabel authorNameLabel = new JLabel("Author Name:");
    private JTextField  mazeNameInput= new JTextField(20);
    private JTextField  authorNameInput= new JTextField(20);




    public DatabaseGUI(JTabbedPane homePane, Database db, MazeGUI MGUI){
        super();

        // Sets parameters for overall window
        setSize(1020, 500);
        setLocation(500, 500);
        setLayout(new BorderLayout());
        JPanel bigPanel = new JPanel();
        bigPanel.setLayout(new GridLayout(2, 1));


        // Creates the menu bar and 'file' item
        JMenuBar menuBar = new JMenuBar();
        menuBar.setOpaque(true);
        menuBar.setPreferredSize(new Dimension(200, 20));
        JMenu menuItem = new JMenu("File");
        menuBar.add(menuItem);


        // Creates the top panel with options
        northPanel = new JPanel();
        JPanel inputPanel = new JPanel();
        JPanel labelPanel = new JPanel();
        JPanel buttonPanel2 = new JPanel();
        buttonPanel2.setLayout(new GridLayout(3, 3, 5, 30));
        inputPanel.setLayout(new GridLayout(3, 3, 5, 27));
        labelPanel.setLayout(new GridLayout(3, 3, 5, 30));
        labelPanel.add(mazeNameLabel);
        inputPanel.add(mazeNameInput);
        labelPanel.add(authorNameLabel);
        inputPanel.add(authorNameInput);
        buttonPanel2.add(saveMazeBtn);
        buttonPanel2.add(updateExistingMazeBtn);
        buttonPanel2.add(deleteMazeBtn);
        buttonPanel2.add(loadMazeBtn);

        northPanel.add(labelPanel);
        northPanel.add(inputPanel);
        northPanel.add(buttonPanel2);

        // Create maze database table
        southPanel = new JPanel();
        southPanel.setLayout(new BorderLayout());
        String[] columnNames = {"Maze Name", "Rows", "Columns", "Creation Date", "Last Updated", "Author"};
        String[][] data = null;
        JTable mazes;
        try{
            data = db.getAllMazes();
        } catch(SQLException e){
            System.out.println("There was an error getting the mazes");
        }
        if(data != null){
            // Create table
            mazes = new JTable(data, columnNames);
            mazes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            mazes.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int row = mazes.getSelectedRow();
                    mazeNameInput.setText((String)mazes.getValueAt(row, 0));
                    authorNameInput.setText((String)mazes.getValueAt(row, 5));
                }
            });
            mazes.setBounds(0, 0, 100, 100);
            // Add it to a scroll pane
            JScrollPane dataScrollPane = new JScrollPane(mazes);
            dataScrollPane.setVerticalScrollBarPolicy(
                    JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            southPanel.add(dataScrollPane);
            southPanel.setVisible(true);
        }


        // Add section to main GUI
        bigPanel.add(northPanel, BorderLayout.NORTH);
        bigPanel.add(southPanel, BorderLayout.SOUTH);

        // Add functionality to buttons
        saveMazeBtn.addActionListener(event -> {
            try{
                //Create new maze object to pass to database
                Maze savedMaze = new Maze(mazeNameInput.getText(),MGUI.rows, MGUI.cols,  MGUI.grid.grid, MGUI.grid.grid);
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                savedMaze.setCreationDate(df.format(new Date()));
                savedMaze.setAuthor(authorNameInput.getText());
                savedMaze.rows = MGUI.rows;
                savedMaze.cols = MGUI.cols;
                if(mazeNameInput.getText() == "" || authorNameInput.getText() == ""){
                    throw new Exception();
                }
                db.saveMaze(savedMaze);
                MazeGUI.CreateMazeGUI(db, null);
                MGUI.dispose();
            } catch(SQLException e){
                JOptionPane.showMessageDialog(this, "There was an error saving to the database, have you filled out all fields?");
            } catch(IOException e){
                JOptionPane.showMessageDialog(this, "A maze with that name already exists.");
            }catch (Exception e){
                JOptionPane.showMessageDialog(this, "There was an error\nHave you filled out all the fields and created & generated a maze?");
            }
        });

        updateExistingMazeBtn.addActionListener(event -> {
            try{
                Maze updatedMaze = new Maze(mazeNameInput.getText(), MGUI.rows, MGUI.cols, MGUI.grid.generation.grid, MGUI.grid.generation.grid);
                db.updateMaze(updatedMaze);
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                updatedMaze.setUpdateDate(df.format(new Date()));
                updatedMaze.setAuthor(authorNameInput.getText());
                updatedMaze.rows = MGUI.rows;
                updatedMaze.cols = MGUI.cols;
                db.updateMaze(updatedMaze);
                MazeGUI.CreateMazeGUI(db, null);
                MGUI.dispose();
                // Catch different errors from function and respond accordingly
            } catch(SQLException e){
                JOptionPane.showMessageDialog(this, "There was an error saving to the database, have you filled out all fields?");
            } catch(FileNotFoundException e){
                JOptionPane.showMessageDialog(this, "Maze name not found, please try again.");
            } catch(IOException e){
                JOptionPane.showMessageDialog(this, "A maze with that name already exists.");
            } catch(NullPointerException e){
                JOptionPane.showMessageDialog(this, "There is no maze data to update.");
            }
        });

        deleteMazeBtn.addActionListener(event -> {
            // Ensure user is sure they want to delete the specified maze
            // ADD LATER

            try{
                Maze deletedMaze = new Maze();
                deletedMaze.mazeName = mazeNameInput.getText();
                if(JOptionPane.showConfirmDialog(this, "Are you sure you want to delete " + mazeNameInput.getText() + "?") == 0){
                    db.deleteMaze(deletedMaze);
                    MazeGUI.CreateMazeGUI(db, null);
                    MGUI.dispose();
                } else{
                    System.out.println("The maze has not been deleted.");
                }
            } catch(FileNotFoundException e){
                System.out.println("The specified maze doesn't exist, please try again.");
            } catch(SQLException e){
                System.out.println("There was an error deleting the maze, have you filled out all needed fields?");
            } catch(IOException e){
                System.out.println("There was an error recreating the GUI, please restart the program.");

            }

        });

        loadMazeBtn.addActionListener(event -> {
            try{
                Maze loaded = db.loadMaze(mazeNameInput.getText());
                if(loaded.mazeName != null){
                    try{
                        MazeGUI.CreateMazeGUI(db, loaded);
                        MazeGUI.started = true;
                        MGUI.dispose();
                    } catch(IOException e){
                        System.out.println("There was an IO error");
                    }
                } else{
                    System.out.println("There was an error loading the specified maze");
                }
            } catch(FileNotFoundException e){
                System.out.println("The specified maze doesn't exist, please try again.");
            } catch(SQLException e){
                System.out.println("There was an error deleting the maze, have you filled out all needed fields?");
            } catch(IOException e){
                System.out.println("There was an error");
            } catch (ClassNotFoundException e){
                System.out.println("There was an error2");

            }


        });

        // Creates the two tabs 'Maze' and 'Database'
        homePane.add("Database", bigPanel);

    }


}
