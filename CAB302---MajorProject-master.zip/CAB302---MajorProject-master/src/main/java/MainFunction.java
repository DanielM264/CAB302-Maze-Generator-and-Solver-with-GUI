import Database.Database;
import GUI.*;

import java.io.File;
import java.io.IOException;

public class MainFunction {
    public static void main(String[] args) throws IOException {
        Database db = new Database();

        MazeGUI maze = null;
            maze.CreateMazeGUI(db, null);


    }

}
