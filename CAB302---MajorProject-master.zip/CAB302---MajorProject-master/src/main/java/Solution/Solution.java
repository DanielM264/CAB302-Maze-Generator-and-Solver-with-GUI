package Solution;

import java.lang.*;

/**
 * This class takes the current maze and returns the best solution.
 * This solution is called by the overlay class but can also be called manually if a solution is wanted by itself
 *
 * @author Oliver Regan
 * @version 1.0
 */
public class Solution {

    /**
     * Fields
     */
    private Object maze;
    public int[] solution;

    /**
     * Constructs a solution for a maze that is passed in as a parameter
     * Checks if maze is loaded from database
     *
     * @param Maze
     */
    public Solution(Object Maze){
        this.maze = Maze;
    }

    /**
     * Derives solution from inputted maze as an array and assigns it to variable
     *
     * Precondition - Maze has been created and is preloaded
     * Postcondtion - Solution array is assigned to variable to be accessed by overlay class
     *
     * @param maze Maze that is to be solved
     */
    private void solveMaze(Object maze){
    }


}
