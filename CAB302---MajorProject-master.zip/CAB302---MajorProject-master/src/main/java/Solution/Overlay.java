package Solution;

import GUI.*;
import Maze.*;
import javax.swing.*;

public class Overlay{


    /**
     * Fields
     */

//    private Solution currentSolution;
//    private Maze Maze;
//
//    /**
//     * Constructs overlay object from given maze
//     *
//     * @param maze Maze to have solution worked out
//     */
//    public Overlay(Maze maze, Solution solution){
//        // Initialize superclass constructor
//        super();
//        oMaze = maze;
//        this.currentSolution = solution;
//

//    }

    /**
     * Generates overlay to be shown over maze in progress or to be saved otherwise
     *
     *
     *
     * Creates overlay from given solution and maze
     *
     * Precondition - Solution has already been created and maze is a valid maze
     * Postcondition - Creates Overlay object for the GUI to display over maze in progress
     *
     * @param currentSolution current solution of current maze
     * @param maze maze for the current solution
     */
//    public JPanel createOverlay(Maze maze, Solution currentSolution) {
//        JPanel j = new JPanel();
//        return j;
//
//    }


}
